
var todo_list = []

function addItem(){
    const title_ele = document.getElementById('title')
    const location_ele = document.getElementById('location')
    const desc_ele = document.getElementById('desc')

    let todo_item = [title_ele.value, location_ele.value, desc_ele.value]

    todo_list.push(todo_item)

    console.log(todo_list)

    title_ele.value  = ""
    location_ele.value = ""
    desc_ele.value = ""

}
